// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace UICatalog
{
	[Register ("AlertsViewController")]
	partial class AlertsViewController
	{
		[Action ("ShowDestructiveAlert:")]
		partial void ShowDestructiveAlert (Foundation.NSObject sender);

		[Action ("ShowOkCancelAlert:")]
		partial void ShowOkCancelAlert (Foundation.NSObject sender);

		[Action ("ShowSimpleAlert:")]
		partial void ShowSimpleAlert (Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
		}
	}
}
