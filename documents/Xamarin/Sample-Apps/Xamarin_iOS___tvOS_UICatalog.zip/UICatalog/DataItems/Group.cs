﻿namespace UICatalog {

	public enum Group {
		Scenery,
		Iceland,
		Lola,
		Baby
	}
}

