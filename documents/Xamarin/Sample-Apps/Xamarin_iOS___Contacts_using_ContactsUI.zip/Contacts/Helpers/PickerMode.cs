﻿
namespace Contacts.Helpers
{
    public enum PickerMode
    {
        Default = 0,
        SingleContact = 1,
        SingleProperty = 2,
        MultupleContacts = 3,
        MultipleProperties = 4
    }
}