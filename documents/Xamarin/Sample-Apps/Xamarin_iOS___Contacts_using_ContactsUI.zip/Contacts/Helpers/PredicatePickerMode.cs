﻿
namespace Contacts.Helpers
{
    public enum PredicatePickerMode
    {
        Default = 0,
        EnableContacts = 1,
        SelectContacts = 2,
    }
}