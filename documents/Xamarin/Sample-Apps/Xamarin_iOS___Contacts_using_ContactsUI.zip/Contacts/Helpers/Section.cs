﻿using System.Collections.Generic;

namespace Contacts.Helpers
{
    public class Section
    {
        public List<string> Items { get; set; }
    }
}