﻿using System;
namespace Tandm
{
	public enum BikeType
	{
		Unicycle,
		Tricycle
	}
}
