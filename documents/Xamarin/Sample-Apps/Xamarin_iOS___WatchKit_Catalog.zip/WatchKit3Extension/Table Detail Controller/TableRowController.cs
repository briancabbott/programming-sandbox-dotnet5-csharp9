﻿/*
 * This is the row controller for the default row type in the table of the table detail controller.
*/

using System;

using WatchKit;
using Foundation;

namespace WatchkitExtension
{
	public partial class TableRowController : NSObject
	{
		public TableRowController ()
		{
		}
	}
}

