﻿/*
 * This is the row controller for the default row type in the table of the initial interface controller.
*/

using System;
using WatchKit;
using Foundation;

namespace WatchkitExtension
{
	public partial class ElementRowController : NSObject
	{
		public ElementRowController ()
		{
		}
	}
}

