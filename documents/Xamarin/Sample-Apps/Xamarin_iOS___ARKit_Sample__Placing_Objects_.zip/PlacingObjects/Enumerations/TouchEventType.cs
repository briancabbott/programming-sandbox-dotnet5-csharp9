﻿using System;
namespace PlacingObjects
{
	public enum TouchEventType
	{
		TouchBegan,
		TouchCanceled,
		TouchMoved,
		TouchEnded
	}
}
