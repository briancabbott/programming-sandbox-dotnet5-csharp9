﻿using System;
namespace PlacingObjects
{
	public enum MessageType
	{
		ContentPlacement,
		FocusSquare,
		PlaneEstimation,
		TrackingStateEscalation
	}
}
