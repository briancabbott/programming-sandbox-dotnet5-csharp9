// WARNING
//
// This file has been generated automatically by Visual Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace PlacingObjects
{
	[Register ("SettingsViewController")]
	partial class SettingsViewController
	{

		[Outlet]
		UIKit.UISwitch DragOnInfinitePlanesSwitch { get; set; }

		[Outlet]
		UIKit.UISwitch ScaleWithPinchGestureSwitch { get; set; }

		void ReleaseDesignerOutlets ()
		{
		}
	}
}
